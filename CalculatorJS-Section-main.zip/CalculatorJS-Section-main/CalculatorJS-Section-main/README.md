"A math Calculator built with just HTML, CSS grid and Vanilla JavaScript. The app is capable of performing your common math operations like addition, deletion, subtraction, multiplication, and division." 

=======
# CalculatorJS-Section
>>>>>>> 34e3f0e5b590171ac2478535aebdfadd99c2d930
